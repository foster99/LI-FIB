%Ejemplo 2:
size(14).
c( blue,       9,10, 12,11).
c( brown,      4,9,  14,10).
c( red,        6,4,  7,8  ).
c( cyan,       7,3,  7,5  ).
c( green,      6,7,  8,8  ).
c( yellow,     8,1,  5,11 ).
c( pink,       11,3, 12,5 ).
c( violet,     5,2,  13,13).
c( orange,     11,4, 9,8  ).
c( darkblue,   2,2,  2,6  ).
c( darkgreen,  10,5, 10,8 ).
c( darkred,    14,11,11,14).
c( darkcyan,   6,5,  3,12 ).
c( white,      9,5,  8,12 ).
c( grey,       14,8, 10,10).
