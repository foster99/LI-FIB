# Practica 1

El objetivo es mejorar el SAT-solver en:
 * [ ] unit_propagation (propagateGivesConflict) usando ocurrList
 * [ ] heuristica de decision (getNextDecisionLiteral)

Hints:
 * Mejorar la heuristica a la hora de DECIDIR.
 * Hacer listas de clausulas en las que una variable aparece positiva/negativa.
 * Intentar mejorar el backtracking.
