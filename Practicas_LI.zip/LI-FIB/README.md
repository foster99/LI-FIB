# LI-FIB
Laboratorios de la asignaura LI en la FIB.
